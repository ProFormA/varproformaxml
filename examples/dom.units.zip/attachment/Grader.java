package dom.units.grader;

import java.util.Scanner;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.proforma.variability.transfer.CVVp;

import de.hsh.graja.graderapi.DiffHelper;
import de.hsh.graja.graderapi.GraderContext;
import de.hsh.graja.graderapi.GrajaRunner;
import de.hsh.graja.graderapi.InjectContext;

/**
 * This is the source code of the test driver contained in the Grader.jar file.
 * The Graja grader at runtime reads the jar file. This source code is included
 * into the task for documentation purposes only. 
 */
@RunWith(GrajaRunner.class)
public class Grader  {
    
    private static GraderContext ctx;
    private static CVVp cv;
    
    @InjectContext
    public static void processContext(GraderContext ctx) {
        Grader.ctx= ctx;
        cv= ctx.getCVVp();
    }
    
    private static class Sample {
        public static double method(double v) {
            return v * cv.getDouble("factor");
        }
        @SuppressWarnings("unused")
        public static void main(String[] args) {
            @SuppressWarnings("resource")
            Scanner console= new Scanner(System.in);
            System.out.print("Convert from "+cv.getString("unit_a")+" to "+cv.getString("unit_b")+": ");
            double val= console.nextDouble();
            System.out.println("Converted value: " + method(val));
        }
    }
    
	private static Class<?> submission;
	
    @BeforeClass public static void setupClass() {
        submission= ctx.getPublicClassForName(cv.getString("class"));
    }
    
    @Test public void test() {
        String input= "5\n";
        DiffHelper.callMain()
        .ofClasses(Sample.class, submission)
        .pipeToSystemIn(input)
        .start();
    }
}
