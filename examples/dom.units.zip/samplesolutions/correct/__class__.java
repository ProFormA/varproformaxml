import java.util.Scanner;

/**
 * This class converts from §(unit_a)§ to §(unit_b)§.
 */
public class §(class)§ {

    /**
     * Converts §(unit_a)§ to §(unit_b)§
     */
    public static double §(method)§(double v) {
        return v * §(factor)§;
    }

    /** 
     * Main program.
     */
    public static void main(String[] args) {
        Scanner console= new Scanner(System.in);
        System.out.print("Convert from §(unit_a)§ to §(unit_b)§: ");
        double val= console.nextDouble();
        System.out.println("Converted value: " + §(method)§(val));
    }
}
