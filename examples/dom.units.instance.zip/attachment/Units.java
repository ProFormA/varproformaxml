import java.util.Scanner;

/**
 * This class converts from kn to km/h.
 */
public class Units {


    /** 
     * Main program.
     */
    public static void main(String[] args) {
        Scanner console= new Scanner(System.in);
        System.out.print("Convert from kn to km/h: ");
        double val= console.nextDouble();
        System.out.println("Converted value: " + toKmh(val));
    }
}
